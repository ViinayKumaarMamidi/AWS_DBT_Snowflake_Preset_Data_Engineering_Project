{% docs __overview__ %}

# Airbnb Snowflake and dbt pipeline

Hi All, welcome to our Airbnb dbt pipeline documentation!

Here is the schema of our input data:

![input schema](assets/input_schema.png)

Hope you enjoyed the documentation!

{% enddocs %}

