{% macro learn_logging() %}
    {{ log("Call your friend!") }}
    {{ log("Call your school friend!", info=True) }} --> Logs to the screen, too
--  {{ log("Call your masters friend!", info=True) }} --> This will be put to the screen
    {# log("Call your boston friend!", info=True) #} --> This won't be executed
{% endmacro %}
